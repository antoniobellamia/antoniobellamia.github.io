/**
 * VERIFICA PRATICA DI INFORMATICA 4D inf 19/03/2024
 * STUDENTE: BELLAMIA ANTONIO
 * GUI PER LA CHIUSURA VOTI ANNO SCOLASTICO
 */


public class Main {
    public static void main(String[] args) {
        new Voti();
    }
}