import javax.swing.*;
import java.awt.*;

public class Voti extends JFrame {

    MainPanel panel;
    public Voti() throws HeadlessException {
        setFrameSettings();
        panel=new MainPanel();
        add(panel);
    }

    private void setFrameSettings(){
        setVisible(true);
        Dimension dim = new Dimension(400, 400);
        setSize(500, 700);
        setMinimumSize(dim);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Chiusura anno scolastico");
    }
}
