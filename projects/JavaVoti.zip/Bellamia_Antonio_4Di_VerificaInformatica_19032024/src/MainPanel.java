import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class MainPanel extends JPanel implements ActionListener {

    public final static int MAX_MATERIE=9;
    private SinglePanel[] pnlMaterie;
    private JPanel pnlRisultati;
    private String[] nomiMaterie = {"Italiano", "Storia", "Matematica", "Complementi di Matematica", "Inglese", "Informatica", "Sistemi e Reti", "TPSIT", "Telecomunicazioni"};
    private int[] voti;

    private JButton chiusura;
    private JLabel media;
    private JLabel minimo;
    private JLabel massimo;
    private JLabel status;

    private final static String DEFAULT_TEXT_MEDIA = "Voto medio: ";
    private final static String DEFAULT_TEXT_MINIMO = "Voto più basso: ";
    private final static String DEFAULT_TEXT_MASSIMO = "Voto più alto: ";
    private final static String DEFAULT_TEXT_STATUS = "Status: ";


    public MainPanel() {
        setVisible(true);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        pnlMaterie=new SinglePanel[MAX_MATERIE];


        for(int i=0; i<MAX_MATERIE; i++){
            pnlMaterie[i] = new SinglePanel(nomiMaterie[i]+":");
            add(pnlMaterie[i]);
        }

        pnlRisultati=new JPanel(new GridLayout(3,2, 10, 10));

        chiusura=new JButton("Chiusura anno scolastico");
        pnlRisultati.add(chiusura);
        chiusura.addActionListener(this);

        setLabels();
        add(pnlRisultati);

    }


    private void setVoti() {

        voti=new int[MAX_MATERIE];

        for(int i=0; i<MAX_MATERIE; i++) {

            try {

                voti[i] = pnlMaterie[i].getValutazione();

            } catch (Exception exc) {
                JOptionPane.showMessageDialog(null, exc.getMessage(), "ERRORE ACQUISIZIONE VOTI", JOptionPane.ERROR_MESSAGE );

                  media.setText(DEFAULT_TEXT_MEDIA + "n/d");
                 minimo.setText(DEFAULT_TEXT_MINIMO + "n/d");
                massimo.setText(DEFAULT_TEXT_MASSIMO + "n/d");
                 status.setText(DEFAULT_TEXT_STATUS + "n/d");

                voti=null;
                break;
            }
        }

    }

    private void setLabels(){
        media = new JLabel(DEFAULT_TEXT_MEDIA + "n/d");
        minimo = new JLabel(DEFAULT_TEXT_MINIMO + "n/d");
        massimo = new JLabel(DEFAULT_TEXT_MASSIMO + "n/d");
        status = new JLabel(DEFAULT_TEXT_STATUS + "n/d");

        pnlRisultati.add(media);
        pnlRisultati.add(minimo);
        pnlRisultati.add(massimo);
        pnlRisultati.add(status);
    }

    public int getVotoMax(){
        int max=voti[0];

        for (int i = 1; i < MAX_MATERIE; i++) {
            if(voti[i]>max) max=voti[i];
        }

        return max;
    }

    public int getVotoMin(){
        int min = voti[0];

        for (int i = 1; i < MAX_MATERIE; i++) {
            if(voti[i]<min) min=voti[i];
        }

        return min;
    }

    public double getVotoMedio(){
        double media=voti[0];

        for (int i = 1; i < MAX_MATERIE; i++) {
            media+=voti[i];
        }

        return media/MAX_MATERIE;
    }

    public boolean isPromosso(){

        for (int i = 0; i < MAX_MATERIE; i++) {
            if(voti[i]<6) return false;
        }

        return true;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == chiusura){

            setVoti();

            if(voti!=null) {
                massimo.setText(DEFAULT_TEXT_MASSIMO + getVotoMax());
                minimo.setText(DEFAULT_TEXT_MINIMO + getVotoMin());
                media.setText(DEFAULT_TEXT_MEDIA + getVotoMedio());

                if (isPromosso()){
                    status.setText(DEFAULT_TEXT_STATUS + "Promosso");
                    JOptionPane.showMessageDialog(null, "Complimenti, sei stato promosso!", "ESITO FINALE", JOptionPane.INFORMATION_MESSAGE);
                }
                else{
                    status.setText(DEFAULT_TEXT_STATUS + "Bocciato");
                    JOptionPane.showMessageDialog(null, "Purtroppo sei stato bocciato.", "ESITO FINALE", JOptionPane.WARNING_MESSAGE);
                }
            }
        }
    }
}
