import javax.swing.*;
import java.awt.*;

public class SinglePanel extends JPanel {
    private JLabel lblMateria;
    private String materia;

    private JTextField field;

    public SinglePanel(String materia) {
        setLayout(new GridLayout(1, 2, 10, 10));
        setVisible(true);
        setMateria(materia);
        lblMateria=new JLabel(getMateria());
        field=new JTextField(2);
        add(lblMateria);
        add(field);
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        if(materia==null || materia.isEmpty() || materia.isBlank()) throw new IllegalArgumentException();
        this.materia = materia;
    }

    public int getValutazione(){

        String[] showMsgMateria = materia.split(":");

        int v=0;

        try {

            String text = field.getText();
             v = Integer.parseInt(text);

        }catch (Exception exc){
            throw new NumberFormatException("Non è possibile elaborare il valore inserito alla voce "+showMsgMateria[0]+".");
        }

        if(v<3||v>10) throw new IllegalArgumentException("Il valore inserito alla voce "+showMsgMateria[0]+" deve essere compreso tra 3 e 10.");

        return v;
    }

}
